from flask import Blueprint, jsonify, current_app

product_bp = Blueprint('product_bp', __name__)

@product_bp.route('/productos')
def obtener_productos():
    try:
        connection = current_app.connection  
        with connection.cursor() as cursor:
            cursor.execute("SELECT nombre, precio FROM productos")  
            productos = cursor.fetchall()
            return jsonify(productos)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
