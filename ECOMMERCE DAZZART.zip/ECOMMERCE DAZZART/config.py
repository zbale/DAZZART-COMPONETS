class Config:
    SECRET_KEY = 'Elcoste022024'  
    MYSQL_HOST = '127.0.0.1'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'SENA'  
    MYSQL_DB = 'DAZZART'   
    SESSION_COOKIE_SECURE = False 