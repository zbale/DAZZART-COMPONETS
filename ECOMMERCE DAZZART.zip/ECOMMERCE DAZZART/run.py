from app import create_app
from app.controllers.product_controller import product_bp  

app = create_app()

if __name__ == "__main__":
    app.run(debug=True)

    